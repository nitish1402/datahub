import pandas as pd
from spacy.lang.en import English
from spacy.pipeline import EntityRuler
from spacy.tokenizer import Tokenizer
import re
import spacy
from enum import Enum
import logging
from datahub.ingestion.glossary.classifier import Classifier
from dataclasses import dataclass
from typing import List, Dict, Any

logger = logging.getLogger(__name__)

logging.basicConfig(
    format="{asctime} - {levelname} - {message}",
    style="{",
    datefmt="%Y-%m-%d %H:%M",
    level=logging.DEBUG,
)

@dataclass
class ColumnInfo:
    name: str
    type: str = None
    confidence: float = 0.0
    val_type: List[Dict[str, Any]] = None

class DataClassificationLabels(Enum):
    PAN = 'PAN'
    EMAIL = 'EMAIL'
    AADHAAR = 'AADHAAR'

class DataClassifier(Classifier):
    """Classify the data in each column using spaCy, extending DataHub's Classifier."""
    
    def __init__(self, df: pd.DataFrame):
        self.df = df
        self.nlp = self.custom_nlp()
        
    def custom_nlp(self):
        nlp = English()
        nlp.tokenizer = Tokenizer(nlp.vocab, token_match=re.compile(r'\S+').match)
        ruler = nlp.add_pipe("entity_ruler")
        patterns = [
            {"label": DataClassificationLabels.PAN.value, "pattern": [{'TEXT': {'REGEX': "^[a-zA-Z]{3}[pPcChHfFatTblLjJgG][A-Za-z][\d]{4}[A-Za-z]$"}}]},
            {"label": DataClassificationLabels.AADHAAR.value, "pattern": [{'TEXT': {'REGEX': "^[2-9]{1}[0-9]{3}[0-9]{4}[0-9]{4}$"}}]},
            {"label": DataClassificationLabels.EMAIL.value, "pattern": [{"LIKE_EMAIL": True}]}
        ]
        ruler.add_patterns(patterns)
        return nlp
        
    def classify(self, columns: List[ColumnInfo]) -> List[ColumnInfo]:
        for column in columns:
            series = self.df[column.name]
            column_metadata = self.extract_series_metadata(column.name, series)
            column.type = column_metadata['type']
            column.confidence = column_metadata['confidence']
            column.val_type = column_metadata['val_type']
        return columns
    
    @classmethod
    def create(cls, config_dict: Dict[str, Any]) -> "DataClassifier":
        df = config_dict.get("df")
        if df is None or not isinstance(df, pd.DataFrame):
            raise ValueError("Invalid or missing DataFrame in configuration.")
        return cls(df)
    
    def extract_series_metadata(self, series_name, series):
        metadata = {'type': None, 'confidence': 0.0, 'val_type': []}
        for val in series:
            new_val = self.aadhaar_pre_process(val)
            res = self.detect_pan_email(new_val)
            metadata['type'] = res['type']
            metadata['confidence'] = res['confidence']
            metadata['val_type'].append({'type': res['type'], 'confidence': res['confidence']})
        
        logger.debug(f"{series_name}: {metadata}")
        return metadata
    
    def detect_pan_email(self, val):
        result = {'type': None, 'confidence': 0.0}
        if val is None:
            return result
        
        nlp_res = self.nlp(str(val))
        detected_labels = [entity.label_ for entity in nlp_res.ents]
        logger.debug(detected_labels)
        
        if not detected_labels:
            return result 
        
        if DataClassificationLabels.PAN.value in detected_labels:
            result['type'] = 'PAN'
            result['confidence'] = 100.0 if PanValidator.validate(val) else 0.0
        if DataClassificationLabels.AADHAAR.value in detected_labels:
            result['type'] = 'AADHAAR'
            result['confidence'] = 100.0 if AadhaarValidator.validate(val) else 0.0
        if DataClassificationLabels.EMAIL.value in detected_labels:
            result['type'] = 'Email'
            result['confidence'] = 100.0
        
        return result
    
    def aadhaar_pre_process(self, val):
        if re.search(r"^[2-9]{1}[0-9]{3}[-|\s][0-9]{4}[-|\s][0-9]{4}$", str(val)):
            return val.replace(' ', '').replace('-', '')
        return val
        
class PanValidator:
    @classmethod
    def validate(cls, val):
        try:
            return int(val[5:9]) != 0
        except ValueError:
            logger.debug("ValueError", exc_info=True)
            return False
    
class AadhaarValidator:
    @staticmethod
    def validate(aadharNum):
        try:
            i = len(aadharNum)
            j = 0
            x = 0
            while i > 0:
                i -= 1
                x = VerhoeffTable.MULTIPLICATION.value[x][VerhoeffTable.PERMUTATION.value[(j % 8)][int(aadharNum[i])]]
                j += 1
            return x == 0
        except (ValueError, IndexError):
            logger.error("Validation Error", exc_info=True)
            return False
    
if __name__ == '__main__':
    df = pd.read_csv('./classification_data.csv')
    columns = [ColumnInfo(name=col) for col in df.columns]
    logger.info(DataClassifier(df).classify(columns))
